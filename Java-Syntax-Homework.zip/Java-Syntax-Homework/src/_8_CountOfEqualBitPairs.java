import java.util.Scanner;


public class _8_CountOfEqualBitPairs {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a positiv integer number : ");
		int n = scan.nextInt();
		String bin = Integer.toBinaryString(n);
        System.out.println(bin);
	}
}

