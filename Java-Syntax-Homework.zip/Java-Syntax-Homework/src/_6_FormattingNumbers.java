import java.util.Locale;
import java.util.Scanner;


public class _6_FormattingNumbers {

	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter  positive integer number a: ");
		int number = scan.nextInt();
		if (number >= 0 && number <= 500) {
			System.out.println("Enter a floating number b: ");
			double dnumber1 = scan.nextDouble();
			System.out.println("Enter a floating number c: ");
			double dnumber2 = scan.nextDouble();
			String line = "|";
			String hex = Integer.toHexString(number).toUpperCase();
			String bin = Integer.toBinaryString(number);
			double binDouble = Double.parseDouble(bin);
			System.out.printf(line + "%-10s" + line + "%010d" 
					+ line + "%10.2f" + line + "%-10.3f"+ line 
					,hex,binDouble,dnumber1,dnumber2);
		}
		else { System.out.println("\"a\" is out of range(a < 0 or a > 500)"
				+ "\nRun the program again!");
		}
	}
}
