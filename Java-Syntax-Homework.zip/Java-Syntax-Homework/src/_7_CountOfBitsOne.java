import java.util.Scanner;


public class _7_CountOfBitsOne {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a positive integer number: ");
		int number = scan.nextInt();
		System.out.println(Integer.bitCount(number));
	}

}
